import '@ecomplus/storefront-template/template/js/'
import './custom-js/pages'
