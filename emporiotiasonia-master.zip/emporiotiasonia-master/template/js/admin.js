import '@ecomplus/storefront-template/template/js/admin'
