// Add your custom JavaScript for checkout here.

window.ecomPaymentApps = [1245, 9001, 9004]
