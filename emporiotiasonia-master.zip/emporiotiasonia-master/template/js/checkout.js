import '@ecomplus/storefront-template/template/js/checkout'
import './custom-js/checkout'
