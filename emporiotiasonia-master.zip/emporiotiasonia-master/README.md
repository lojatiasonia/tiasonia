# Empório Tia Sônia

https://www.emporiotiasonia.com.br/

## storefront

[![CodeFactor](https://www.codefactor.io/repository/github/ecomclub/storefront/badge)](https://www.codefactor.io/repository/github/ecomclub/storefront)
[![license mit](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Netlify Status](https://api.netlify.com/api/v1/badges/ac85a3a2-c06d-4e69-98ce-40c2190db198/deploy-status)](https://app.netlify.com/sites/tiasonia/deploys)

PWA and JAMstack based e-commerce template for E-Com Plus stores

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?stack=cms&repository=https://github.com/ecomclub/storefront)

[TEMPLATE CHANGELOG](https://github.com/ecomclub/storefront-template/blob/master/CHANGELOG.md)

**WIP**
